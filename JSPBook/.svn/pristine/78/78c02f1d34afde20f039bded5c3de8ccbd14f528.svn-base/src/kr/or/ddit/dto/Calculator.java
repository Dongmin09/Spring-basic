package kr.or.ddit.dto;

public class Calculator {
	
	//기본생성자
//	public Calculator() {
//		
//	}

	//메소드
	public int process(int n) {
		//3제곱
		return n*n*n;
	}
}
