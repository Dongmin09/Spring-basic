package kr.or.ddit.dao;

public class test1 {

	public static void main(String[] args) {
		int i, result = 1;
		
	}

}
